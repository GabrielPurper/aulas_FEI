var canvas = document.getElementById('meuCanvas'); // Peguei o ID do Canvas chamado meuCanvas

// Colocar const = getContext("2d") para idenificar que é em 2d
var ctx = canvas.getContext('2d');

// 1. Função para desenhar quadrado
function desenhar_quadrado(x, y, tamanho, cor) {
    //Tipo da cor do quadrado
    ctx.fillStyle = cor;
    ctx.fillRect(x, y, tamanho, tamanho);
}

// 2. Função para desenhar linha
function desenhar_linha(x1, y1, x2, y2, x3, y3, cor, espessura, corPreenchimento) {
    //Abre o desenho atual
    ctx.beginPath();
    // Cor do pincel
    ctx.strokeStyle = cor; 
    ctx.lineWidth = espessura;
    ctx.fillStyle = corPreenchimento;
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.lineTo(x3, y3);
    ctx.fill();
}

// 3. Função para desenhar arco (pode ser usado para círculos)
function desenhar_arco(x, y, raio, anguloInicial, anguloFinal, corPreenchimento) {
    ctx.beginPath();
    ctx.fillStyle = corPreenchimento;
    ctx.arc(x, y, raio, anguloInicial, anguloFinal);
    //Preenche a cor da circuferência
    ctx.fill(); 
}

// 4. Função para escrever texto
function escrever(texto, x, y, cor, fonte = "20px Arial") {
    //Cor da escrita
    ctx.fillStyle = cor;
    //Fonte 
    ctx.font = fonte;
    // Deixar o texto junto
    ctx.textoAling ="center"
    ctx.fillText(texto, x, y);
}

function desenharCenaExemplo() {

    // Casa
    desenhar_quadrado(100,150,100,"brown");

    // Janela
    desenhar_quadrado(160, 180, 30, "blue");
    
    // Janela 2 
    desenhar_quadrado(110, 180, 30,"blue");

    // Porta
    desenhar_quadrado(140, 220, 20, "red");

    desenhar_quadrado(140, 220, 20, "red");

    desenhar_quadrado(140, 210, 20, "red");

    desenhar_quadrado(140, 230, 20, "red");

    desenhar_quadrado(0,240,60,"dodgerblue");


    // Árvore
    desenhar_quadrado(40,240,20,"brown");
    
    desenhar_quadrado(40,220,20,"brown");

    desenhar_quadrado(40,210,20,"brown");

    desenhar_quadrado(40,200,20,"brown");

    // Circuferência da árvore

    desenhar_arco(50, 180, 25, 0, 2 * Math.PI, "green");

    desenhar_arco(0, 230, 40, 0, 2 * Math.PI, "dodgerblue");

    desenhar_quadrado(40,250,300,"gray");
    

    // Árvore 

    desenhar_quadrado(270, 230, 15, "brown")

    desenhar_quadrado(260, 250, 20, "brown")

    desenhar_quadrado(260, 260, 20, "brown")


    // Circuferência da árvore

    desenhar_arco(270, 230, 25 ,0 , 2 * Math.PI,"green");


    desenhar_quadrado(20,270,60,"dodgeblue");

    desenhar_arco(100, 300, 30, 10, 3 * Math.PI, "dodgerblue");

    // Desenha uma linha da casa
    desenhar_linha(100, 150, 200, 150, 150, 100, "orange", "orange", "orange");

    // Desenha um círculo (arco de 0 a 2π) verde
    desenhar_arco(230, 60, 50, 0, 2 * Math.PI, "yellow");

}

// Executa o desenho
desenharCenaExemplo();