// ==========================================
// IMPORTAÇÃO DE MÓDULOS
// ==========================================
const http = require('http');
const express = require('express');
const colors = require('colors');
const bodyParser = require('body-parser');
const path = require('path');
const { MongoClient, ObjectId } = require('mongodb');

const app = express();

// ==========================================
// CONFIGURAÇÕES DO MONGODB ATLAS
// ==========================================
// IMPORTANTE: Substitua <db_password> pela sua senha real do Atlas
const uri = "mongodb+srv://biodaspurper_db_user:<db_password>@cluster0.uobohkh.mongodb.net/?appName=Cluster0";
const client = new MongoClient(uri);
const dbName = 'exemplo_bd';
let db, colecaoUsuarios, colecaoPosts, colecaoCarros;

async function conectarBanco() {
    try {
        await client.connect();
        console.log(' -> [DATABASE] Conectado ao MongoDB Atlas com sucesso!'.green);
        db = client.db(dbName);
        
        // Inicializa as coleções no Banco de Dados
        colecaoUsuarios = db.collection('usuarios');
        colecaoPosts = db.collection('posts');
        colecaoCarros = db.collection('carros');
    } catch (err) {
        console.error(' -> [DATABASE] Erro ao conectar ao MongoDB:'.red, err);
    }
}
conectarBanco();

// ==========================================
// CONFIGURAÇÕES DE PASTAS E MIDDLEWARES
// ==========================================
const baseFiles = path.join(__dirname, 'public', 'Full Stack', 'Projeto_HTML');

app.use(express.static(baseFiles));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.set('view engine', 'ejs');
app.set('views', './views');

// ==========================================
// "BANCO DE DADOS" EM MEMÓRIA (LAB EXTRA)
// ==========================================
let listaUsuariosMemoria = [];
let listaProdutosMemoria = [];

// ==========================================
// ROTAS DE NAVEGAÇÃO PRINCIPAL
// ==========================================

app.get('/', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Project.html'));
});

// ==========================================
// ROTAS DO LAB EXTRA (EM MEMÓRIA - SEM BANCO)
// ==========================================

app.get('/cadastra', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Get', 'Cadastro.html'));
});

app.post('/salvar-usuario', (req, res) => {
    if (listaUsuariosMemoria.length < 10) {
        const { usuario, senha } = req.body;
        listaUsuariosMemoria.push({ usuario, senha });
        res.redirect('/listar-usuarios');
    } else {
        res.send("<h1>Erro: Limite de 10 usuários atingido!</h1>");
    }
});

app.get('/listar-usuarios', (req, res) => {
    res.render('usuarios', { usuarios: listaUsuariosMemoria });
});

app.get('/cadastro-produto', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Atividade', 'cadastro_produto.html'));
});

app.post('/salvar-produto', (req, res) => {
    if (listaProdutosMemoria.length < 10) {
        const { nome, preco } = req.body;
        listaProdutosMemoria.push({ nome, preco: parseFloat(preco) });
        res.redirect('/listar-produtos');
    } else {
        res.send("<h1>Erro: Limite de 10 produtos atingido!</h1>");
    }
});

app.get('/listar-produtos', (req, res) => {
    res.render('produtos', { produtos: listaProdutosMemoria });
});

// ==========================================
// ROTAS DE USUÁRIO (SISTEMA COM MONGODB)
// ==========================================

app.post('/finalizar-cadastro', async (req, res) => {
    const { usuario, senha } = req.body;
    await colecaoUsuarios.insertOne({ usuario, senha });
    res.render('resposta', { usuario, status: "Cadastro Realizado no Banco!" });
});

app.post('/validar-login', async (req, res) => {
    const { usuario, senha } = req.body;
    const userFound = await colecaoUsuarios.findOne({ usuario, senha });
    
    if (userFound) {
        res.render('resposta', { usuario: userFound.usuario, status: "Login Confirmado via MongoDB" });
    } else {
        res.send("Usuário ou senha incorretos no Banco de Dados.");
    }
});

// ==========================================
// ROTAS DO BLOG (SISTEMA COM MONGODB)
// ==========================================

app.get('/blog', async (req, res) => {
    const listaPosts = await colecaoPosts.find({}).toArray();
    res.render('blog', { posts: listaPosts });
});

app.post('/salvar-post', async (req, res) => {
    const { titulo, resumo, conteudo } = req.body;
    await colecaoPosts.insertOne({ titulo, resumo, conteudo });
    res.redirect('/blog');
});

// ==========================================
// ROTAS DE CARROS (CRUD NO MONGODB)
// ==========================================

app.get('/gerencia-carros', async (req, res) => {
    const listaCarros = await colecaoCarros.find({}).toArray();
    res.render('gerencia_carros', { carros: listaCarros });
});

app.post('/salvar-carro', async (req, res) => {
    const { marca, modelo, ano, qtde_disponivel } = req.body;
    await colecaoCarros.insertOne({
        marca,
        modelo,
        ano: parseInt(ano),
        qtde_disponivel: parseInt(qtde_disponivel)
    });
    res.redirect('/gerencia-carros');
});

app.get('/deletar-carro/:id', async (req, res) => {
    const id = req.params.id;
    await colecaoCarros.deleteOne({ _id: new ObjectId(id) });
    res.redirect('/gerencia-carros');
});

app.get('/vender-carro/:id', async (req, res) => {
    const id = req.params.id;
    await colecaoCarros.updateOne(
        { _id: new ObjectId(id), qtde_disponivel: { $gt: 0 } },
        { $inc: { qtde_disponivel: -1 } }
    );
    res.redirect('/gerencia-carros');
});

// ==========================================
// INICIALIZAÇÃO
// ==========================================
const server = http.createServer(app);
server.listen(80, () => {
    console.log('=========================================='.cyan);
    console.log('   SERVIDOR FEI (ATLAS + MEMÓRIA) RODANDO'.rainbow);
    console.log('   Acesse: http://localhost/'.yellow);
    console.log('=========================================='.cyan);
});