// ==========================================
// IMPORTAÇÃO DE MÓDULOS (BIBLIOTECAS)
// ==========================================
var http = require('http');           // Módulo nativo para criar o servidor HTTP
var express = require('express');     // Framework para facilitar o roteamento e gerenciamento do servidor
var colors = require('colors');       // Biblioteca para colorir mensagens no terminal (estética)
var bodyParser = require('body-parser'); // Middleware para processar dados enviados em formulários (req.body)
var path = require('path');           // Módulo para manipular caminhos de arquivos e pastas

var app = express(); // Inicializa a aplicação Express

// ==========================================
// CONEXÃO COM O MONGODB
// ==========================================
// 'projeto_fei' é o nome do banco que será criado
mongoose.connect('mongodb://127.0.0.1:27017/projeto_fei')
    .then(() => console.log('Conectado ao MongoDB com sucesso!'.green))
    .catch(err => console.error('Erro ao conectar ao MongoDB:', err));

// SENHA MONGO
// Dj33ZRJUQ0AhjjYb

// ==========================================
// MODELOS (SCHEMAS) DO BANCO DE DADOS
// ==========================================
const Usuario = mongoose.model('Usuario', new mongoose.Schema({
    usuario: { type: String, required: true },
    senha: { type: String, required: true }
}));

const Produto = mongoose.model('Produto', new mongoose.Schema({
    nome: String,
    preco: Number
}));

const Post = mongoose.model('Post', new mongoose.Schema({
    titulo: String,
    resumo: String,
    conteudo: String
}));

const Carro = mongoose.model('Carro', new mongoose.Schema({
    marca: String,
    modelo: String,
    ano: Number,
    qtde_disponivel: Number
}));

// ==========================================
// CONFIGURAÇÕES DE PASTAS E MIDDLEWARES
// ==========================================

// Define o caminho base onde os arquivos front-end (HTML estático) estão localizados
const baseFiles = path.join(__dirname, 'public', 'Full Stack', 'Projeto_HTML');

// Define que a pasta 'baseFiles' servirá arquivos estáticos (CSS, JS de cliente, Imagens)
app.use(express.static(baseFiles));

// Configura o Body-Parser para entender dados de formulários HTML (URL encoded) e JSON
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Configuração do Motor de Visualização (Template Engine)
app.set('view engine', 'ejs'); // Define o EJS como motor para renderizar HTML dinâmico
app.set('views', './views');   // Define que as páginas .ejs estarão na pasta '/views'

// ==========================================
// "BANCO DE DADOS" TEMPORÁRIO (EM MEMÓRIA)
// ==========================================
let bancoPosts = []; // Armazena as postagens do blog enquanto o servidor estiver rodando
let bancoCarros = [  // Lista inicial de carros para teste
    { id: 1, marca: "Fiat", modelo: "Uno", ano: 2010, qtde_disponivel: 5 },
    { id: 2, marca: "VW", modelo: "Gol", ano: 2022, qtde_disponivel: 0 }
];

// =========================================
// Banco de Dados Com a Coleção
// =========================================

var dbo = client.db("usuario_bd");
var usuarios = dbo.Collection("usuarios");

var dbo = client.db("carros_bd");
var carros = dbo.Collection("carros");

// ==========================================
// ARRAYS PARA O "LAB EXTRA" (SEM BANCO DE DADOS)
// ==========================================
let listaUsuarios = [];
let listaProdutos = [];

// ==========================================
// ROTAS DO LAB EXTRA (USUÁRIOS E PRODUTOS)
// ==========================================

// Cadastro de Usuários
app.get('/cadastra', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Get', 'Cadastro.html'));
});

app.post("/cadastrar_usuario", function(req, resp) {
    var data = { db_nome: req.body.nome, db_login: req.body.login, db_senha: req.body.senha };

    usuarios.insertOne(data, function (err) {
      console.log(err)
      if (err) {
        resp.render('resposta_usuario', {resposta: "Erro ao cadastrar usuário!"})
      }else {
        resp.render('resposta_usuario', {resposta: "Usuário cadastrado com sucesso!"})        
      };
    });
   
  });


app.post('/salvar-usuario', (req, res) => {
    if (listaUsuarios.length < 10) {
        const { usuario, senha } = req.body;
        listaUsuarios.push({ usuario, senha });
        res.redirect('/listar-usuarios');
    } else {
        res.send("<h1>Erro: Limite de 10 usuários atingido!</h1>");
    }
});

app.get('/listar-usuarios', (req, res) => {
    res.render('usuarios', { usuarios: listaUsuarios });
});

// Cadastro de Produtos
app.get('/cadastro-produto', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Atividade', 'cadastro_produto.html'));
});

// Aqui aonde vai entrar no EJS
app.post('/salvar-produto', (req, res) => {
    if (listaProdutos.length < 10) {
        const { nome, preco } = req.body;
        listaProdutos.push({ nome, preco: parseFloat(preco) });
        res.redirect('/listar-produtos');
    } else {
        res.send("<h1>Erro: Limite de 10 produtos atingido!</h1>");
    }
});

app.get('/listar-produtos', (req, res) => {
    res.render('produtos', { produtos: listaProdutos });
});

// ==========================================
// ROTAS DE NAVEGAÇÃO PRINCIPAL (PÁGINAS FIXAS)
// ==========================================

// Rota da Página Inicial (Home)
app.get('/', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Project.html'));
});

// CADASTRO: Recebe os dados e renderiza o EJS
app.post('/finalizar-cadastro', (req, res) => {
    var usuario = req.body.usuario;
    var senha = req.body.senha;
    // Renderiza o arquivo views/resposta.ejs
    res.render('resposta', { usuario: usuario, senha: senha });
});

// 3. Rota UNIVERSAL de resposta (Processa tanto Login quanto Cadastro)
// No seu HTML, o <form action="/finalizar-cadastro" ou "/validar-login">
app.post(['/finalizar-cadastro', '/validar-login'], (req, res) => {
    // IMPORTANTE: No HTML, o input deve ser <input name="usuario">
    var usuario = req.body.usuario; 
    var senha = req.body.senha;

    console.log(`[SISTEMA] Tentativa de acesso: User: ${usuario}`.rainbow);

    // Renderiza o arquivo 'views/resposta.ejs'
    // Ele vai mostrar o "Status do Login" que você criou
    res.render('resposta', { 
        usuario: usuario, 
        senha: senha 
    });
});

// LOGIN: Abre o formulário
app.get('/login', (req, res) => {
    res.sendFile(__dirname + '/public/Full Stack/Projeto_HTML/Get/Login.html');
});

 app.post("/logar_usuario", function(req, resp) {
    var data = {db_login: req.body.login, db_senha: req.body.senha };

    usuarios.find(data).toArray(function(err, items) {
      console.log(items);
      if (items.length == 0) {
        resp.render('resposta_usuario', {resposta: "Usuário/senha não encontrado!"})
      }else if (err) {
        resp.render('resposta_usuario', {resposta: "Erro ao logar usuário!"})
      }else {
        resp.render('resposta_usuario', {resposta: "Usuário logado com sucesso!"})        
      };
    });

  });

     
  app.post("/remover_usuario", function(req, resp) {
    var data = { db_login: req.body.login, db_senha: req.body.senha };
   
    usuarios.deleteOne(data, function (err, result) {
      console.log(result);
      if (result.deletedCount == 0) {
        resp.render('resposta_usuario', {resposta: "Usuário/senha não encontrado!"})
      }else if (err) {
        resp.render('resposta_usuario', {resposta: "Erro ao remover usuário!"})
      }else {
        resp.render('resposta_usuario', {resposta: "Usuário removido com sucesso!"})        
      };
    });

  });



/* LOGIN: Recebe os dados e renderiza o EJS
app.post('/validar-login', (req, res) => {
    var usuario = req.body.usuario;
    var senha = req.body.senha;
    // Renderiza o arquivo views/resposta.ejs
    res.render('resposta', { usuario: usuario, senha: senha });
});*/


// ==========================================
// ROTAS DO BLOG (SISTEMA DE POSTS)
// ==========================================

// Lista todos os posts armazenados no array 'bancoPosts'
app.get('/blog', (req, res) => {
    res.render('blog', { posts: bancoPosts });
});

// Exibe o formulário para criar uma nova postagem
app.get('/novo-post', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Blog', 'cadastrar_post.html'));
});

// Recebe o conteúdo do novo post e adiciona ao "banco"
app.post('/salvar-post', (req, res) => {
    const { titulo, resumo, conteudo } = req.body;
    bancoPosts.push({ titulo, resumo, conteudo }); // Salva no array
    res.redirect('/blog'); // Redireciona de volta para a lista de posts
});

// ==========================================
// ROTAS DE CARROS (CRUD - Create, Read, Update, Delete)
// ==========================================

app.get('/loginCarro', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Carros', 'Login.html'));
});

app.get('/cadastrarCarro', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Carros', 'Cadastro.html'));
});

// 1. CREATE (Form): Abre o formulário de cadastro de veículos
app.get('/novo-carro', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Carros', 'Carros.html'));
});

// 2. CREATE (Ação): Recebe o POST e salva o novo carro no array
app.post('/salvar-carro', (req, res) => {
    const { marca, modelo, ano, qtde_disponivel } = req.body;
    
    bancoCarros.push({
        id: bancoCarros.length + 1, // Gera um ID baseado no tamanho da lista
        marca: marca,
        modelo: modelo,
        ano: parseInt(ano), // Converte string para número
        qtde_disponivel: parseInt(qtde_disponivel)
    });
    
    res.redirect('/gerencia-carros'); // Redireciona para o painel de gerenciamento
});

// 3. READ: Exibe o painel de gerenciamento (onde tem botões de vender e excluir)
app.get('/gerencia-carros', (req, res) => {
    res.render('gerencia_carros', { carros: bancoCarros });
});

// 4. READ: Exibe apenas a listagem simples para o usuário final
app.get('/carros', (req, res) => {
    res.render('listagem_carros', { carros: bancoCarros });
});

// ==========================================
// OPERAÇÃO: DELETE (Remover Carro da Lista)
// ==========================================
app.get('/deletar-carro/:id', (req, res) => {
    const id = parseInt(req.params.id); // Pega o ID enviado na URL
    // Mantém na lista apenas os carros que possuem ID diferente do que foi clicado
    bancoCarros = bancoCarros.filter(carro => carro.id !== id);
    res.redirect('/gerencia-carros');
});

// ==========================================
// OPERAÇÃO: UPDATE (Simulação de Venda/Baixa de Estoque)
// ==========================================
app.get('/vender-carro/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const carro = bancoCarros.find(c => c.id === id); // Procura o carro pelo ID

    // Se o carro existir e o estoque for maior que zero
    if (carro && carro.qtde_disponivel > 0) {
        carro.qtde_disponivel -= 1; // Subtrai 1 unidade
    }

    res.redirect('/gerencia-carros');
});

// ==========================================
// INICIALIZAÇÃO DO SERVIDOR
// ==========================================

var server = http.createServer(app); // Cria o servidor usando a configuração do Express
server.listen(80, () => {
    // Exibe mensagens estilizadas no console quando o servidor sobe
    console.log('=========================================='.cyan);
    console.log('   SERVIDOR FEI RODANDO (PORTA 80)'.rainbow);
    console.log('   Acesse: http://localhost/'.yellow);
    console.log('=========================================='.cyan);
});