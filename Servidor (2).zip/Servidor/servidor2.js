// ==========================================
// IMPORTAÇÃO DE MÓDULOS
// ==========================================
var http = require('http');
var express = require('express');
var colors = require('colors');
var bodyParser = require('body-parser');
var path = require('path');
var mongoose = require('mongoose'); // IMPORTANTE: Adicionado MongoDB

var app = express();

// ==========================================
// CONEXÃO COM O MONGODB
// ==========================================
// 'projeto_fei' é o nome do banco que será criado
mongoose.connect('mongodb://127.0.0.1:27017/projeto_fei')
    .then(() => console.log('Conectado ao MongoDB com sucesso!'.green))
    .catch(err => console.error('Erro ao conectar ao MongoDB:', err));

// ==========================================
// MODELOS (SCHEMAS) DO BANCO DE DADOS
// ==========================================
const Usuario = mongoose.model('Usuario', new mongoose.Schema({
    usuario: { type: String, required: true },
    senha: { type: String, required: true }
}));

const Produto = mongoose.model('Produto', new mongoose.Schema({
    nome: String,
    preco: Number
}));

const Post = mongoose.model('Post', new mongoose.Schema({
    titulo: String,
    resumo: String,
    conteudo: String
}));

const Carro = mongoose.model('Carro', new mongoose.Schema({
    marca: String,
    modelo: String,
    ano: Number,
    qtde_disponivel: Number
}));

// ==========================================
// CONFIGURAÇÕES E MIDDLEWARES
// ==========================================
const baseFiles = path.join(__dirname, 'public', 'Full Stack', 'Projeto_HTML');
app.use(express.static(baseFiles));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.set('views', './views');

// ==========================================
// ROTAS DE USUÁRIOS (MONGO)
// ==========================================
app.get('/cadastra', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Get', 'Cadastro.html'));
});

app.post('/salvar-usuario', async (req, res) => {
    try {
        const novoUser = new Usuario(req.body);
        await novoUser.save();
        res.redirect('/listar-usuarios');
    } catch (err) {
        res.status(500).send("Erro ao salvar usuário");
    }
});

app.get('/listar-usuarios', async (req, res) => {
    const usuarios = await Usuario.find();
    res.render('usuarios', { usuarios });
});

// Resposta universal para Login/Cadastro
app.post(['/finalizar-cadastro', '/validar-login'], async (req, res) => {
    const { usuario, senha } = req.body;
    // Opcional: Salvar no banco toda vez que logar/cadastrar aqui também
    res.render('resposta', { usuario, senha });
});

// ==========================================
// ROTAS DE PRODUTOS (MONGO)
// ==========================================
app.post('/salvar-produto', async (req, res) => {
    try {
        const novoProduto = new Produto({
            nome: req.body.nome,
            preco: parseFloat(req.body.preco)
        });
        await novoProduto.save();
        res.redirect('/listar-produtos');
    } catch (err) {
        res.send("Erro ao salvar produto");
    }
});

app.get('/listar-produtos', async (req, res) => {
    const produtos = await Produto.find();
    res.render('produtos', { produtos });
});

// ==========================================
// ROTAS DO BLOG (MONGO)
// ==========================================
app.get('/blog', async (req, res) => {
    const posts = await Post.find();
    res.render('blog', { posts });
});

app.post('/salvar-post', async (req, res) => {
    await new Post(req.body).save();
    res.redirect('/blog');
});

// ==========================================
// ROTAS DE CARROS (CRUD MONGO)
// ==========================================
app.post('/salvar-carro', async (req, res) => {
    const { marca, modelo, ano, qtde_disponivel } = req.body;
    await new Carro({
        marca, modelo, 
        ano: parseInt(ano), 
        qtde_disponivel: parseInt(qtde_disponivel)
    }).save();
    res.redirect('/gerencia-carros');
});

app.get('/gerencia-carros', async (req, res) => {
    const carros = await Carro.find();
    res.render('gerencia_carros', { carros });
});

app.get('/deletar-carro/:id', async (req, res) => {
    await Carro.findByIdAndDelete(req.params.id);
    res.redirect('/gerencia-carros');
});

app.get('/vender-carro/:id', async (req, res) => {
    const carro = await Carro.findById(req.params.id);
    if (carro && carro.qtde_disponivel > 0) {
        carro.qtde_disponivel -= 1;
        await carro.save();
    }
    res.redirect('/gerencia-carros');
});

// ==========================================
// INICIALIZAÇÃO
// ==========================================
var server = http.createServer(app);
server.listen(80, () => {
    console.log('=========================================='.cyan);
    console.log('   SERVIDOR FEI COM MONGODB RODANDO'.rainbow);
    console.log('   http://localhost/'.yellow);
    console.log('=========================================='.cyan);
});