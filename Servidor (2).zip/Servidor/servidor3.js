// ==========================================
// IMPORTAÇÃO DE MÓDULOS
// ==========================================
var http = require('http');
var express = require('express');
var colors = require('colors');
var bodyParser = require('body-parser');
var path = require('path');
var mongoose = require('mongoose');

var app = express();

// ==========================================
// CONEXÃO COM O MONGODB ATLAS
// ==========================================
// Substituí o IP local pela sua string do Atlas com a senha fornecida
const uri = "mongodb+srv://biodaspurper_db_user:Dj33ZRJUQ0AhjjYb@cluster0.uobohkh.mongodb.net/?appName=Cluster0";

mongoose.connect(uri)
    .then(() => console.log('Conectado ao MongoDB Atlas com sucesso!'.green))
    .catch(err => console.error('Erro ao conectar ao MongoDB:'.red, err));

// ==========================================
// MODELOS (SCHEMAS) DO BANCO DE DADOS
// ==========================================
const Usuario = mongoose.model('Usuario', new mongoose.Schema({
    db_nome: String,
    db_login: { type: String, required: true },
    db_senha: { type: String, required: true }
}));

const Carro = mongoose.model('Carro', new mongoose.Schema({
    marca: String,
    modelo: String,
    ano: Number,
    qtde_disponivel: Number
}));

const Post = mongoose.model('Post', new mongoose.Schema({
    titulo: String,
    resumo: String,
    conteudo: String
}));

// ==========================================
// CONFIGURAÇÕES DE PASTAS E MIDDLEWARES
// ==========================================
const baseFiles = path.join(__dirname, 'public', 'Full Stack', 'Projeto_HTML');
app.use(express.static(baseFiles));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.set('views', './views');

// ==========================================
// ROTAS DE USUÁRIOS (MONGODB ATLAS)
// ==========================================

app.get('/cadastra', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Get', 'Cadastro.html'));
});

// Cadastrar Usuário no Banco
app.post("/cadastrar_usuario", async (req, resp) => {
    try {
        const novoUsuario = new Usuario({
            db_nome: req.body.nome,
            db_login: req.body.login,
            db_senha: req.body.senha
        });
        await novoUsuario.save();
        resp.render('resposta_usuario', { resposta: "Usuário cadastrado com sucesso!" });
    } catch (err) {
        resp.render('resposta_usuario', { resposta: "Erro ao cadastrar usuário!" });
    }
});

// Login de Usuário (Busca no Banco)
app.post("/logar_usuario", async (req, resp) => {
    try {
        const user = await Usuario.findOne({ db_login: req.body.login, db_senha: req.body.senha });
        if (!user) {
            resp.render('resposta_usuario', { resposta: "Usuário/senha não encontrado!" });
        } else {
            resp.render('resposta_usuario', { resposta: "Usuário logado com sucesso!" });
        }
    } catch (err) {
        resp.render('resposta_usuario', { resposta: "Erro ao logar!" });
    }
});

// Remover Usuário
app.post("/remover_usuario", async (req, resp) => {
    try {
        const result = await Usuario.deleteOne({ db_login: req.body.login, db_senha: req.body.senha });
        if (result.deletedCount == 0) {
            resp.render('resposta_usuario', { resposta: "Usuário não encontrado!" });
        } else {
            resp.render('resposta_usuario', { resposta: "Usuário removido com sucesso!" });
        }
    } catch (err) {
        resp.render('resposta_usuario', { resposta: "Erro ao remover!" });
    }
});

// ==========================================
// ROTAS DE CARROS (MONGODB ATLAS)
// ==========================================

app.get('/gerencia-carros', async (req, res) => {
    const carros = await Carro.find();
    res.render('gerencia_carros', { carros: carros });
});

app.post('/salvar-carro', async (req, res) => {
    const novoCarro = new Carro({
        marca: req.body.marca,
        modelo: req.body.modelo,
        ano: parseInt(req.body.ano),
        qtde_disponivel: parseInt(req.body.qtde_disponivel)
    });
    await novoCarro.save();
    res.redirect('/gerencia-carros');
});

app.get('/deletar-carro/:id', async (req, res) => {
    await Carro.findByIdAndDelete(req.params.id);
    res.redirect('/gerencia-carros');
});

// ==========================================
// NAVEGAÇÃO PRINCIPAL E RESPOSTA UNIVERSAL
// ==========================================

app.get('/', (req, res) => {
    res.sendFile(path.join(baseFiles, 'Project.html'));
});

app.post(['/finalizar-cadastro', '/validar-login'], (req, res) => {
    res.render('resposta', { usuario: req.body.usuario, senha: req.body.senha });
});

// ==========================================
// INICIALIZAÇÃO DO SERVIDOR
// ==========================================
var server = http.createServer(app);
server.listen(80, () => {
    console.log('=========================================='.cyan);
    console.log('   SERVIDOR FEI RODANDO NO ATLAS (PORTA 80)'.rainbow);
    console.log('   http://localhost/'.yellow);
    console.log('=========================================='.cyan);
});