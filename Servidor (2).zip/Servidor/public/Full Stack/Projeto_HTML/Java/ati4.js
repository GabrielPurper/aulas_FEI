function processarAlunos(listaAlunos) {
    // listaAlunos deve ser um array de objetos: [{n1: 5, n2: 7}, ...]
    listaAlunos.forEach((aluno, index) => {
        const media = (aluno.n1 + aluno.n2) / 2;
        let mensagem = "";

        if (media <= 3.0) mensagem = "Reprovado";
        else if (media < 7.0) mensagem = "Exame";
        else mensagem = "Aprovado";

        console.log(`Aluno ${index + 1}: Média ${media.toFixed(1)} - ${mensagem}`);
    });
}

// Exemplo de teste com 6 alunos
const notas = [
    { n1: 2, n2: 3 }, { n1: 5, n2: 6 }, { n1: 8, n2: 9 },
    { n1: 3, n2: 3 }, { n1: 10, n2: 7 }, { n1: 4, n2: 5 }
];
processarAlunos(notas);