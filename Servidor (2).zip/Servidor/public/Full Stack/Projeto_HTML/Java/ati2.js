function classificarPessoa(altura, peso) {
    let classe = "";

    if (altura < 1.20) {
        if (peso <= 60) classe = "A";
        else if (peso <= 90) classe = "D";
        else classe = "G";
    } 
    else if (altura >= 1.20 && altura <= 1.70) {
        if (peso <= 60) classe = "B";
        else if (peso <= 90) classe = "E";
        else classe = "H";
    } 
    else { // Maiores que 1.70
        if (peso <= 60) classe = "C";
        else if (peso <= 90) classe = "F";
        else classe = "I";
    }

    console.log(`Altura: ${altura}m | Peso: ${peso}kg | Classificação: ${classe}`);
}

classificarPessoa(1.75, 80); // Exemplo