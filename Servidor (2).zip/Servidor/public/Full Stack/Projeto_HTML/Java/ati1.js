function ordenarNumeros(i, a, b, c) {
    let nums = [a, b, c];

    if (i === 1) {
        // Ordem Crescente
        nums.sort((x, y) => x - y);
    } else if (i === 2) {
        // Ordem Decrescente
        nums.sort((x, y) => y - x);
    } else if (i === 3) {
        // O maior fica no meio
        nums.sort((x, y) => x - y); // Ordena primeiro
        let maior = nums.pop();      // Tira o maior
        nums.splice(1, 0, maior);    // Coloca no meio (índice 1)
    }

    console.log(`Resultado (I=${i}):`, nums);
}

// Exemplo: I=3 (Maior no meio)
ordenarNumeros(3, 10, 5, 50);