function calcularConceito(n1, n2, n3) {
    // Cálculo da média ponderada: (nota * peso) / soma dos pesos
    const media = ((n1 * 2) + (n2 * 3) + (n3 * 5)) / 10;

    let conceito = "";
    if (media >= 8) conceito = "A";
    else if (media >= 7) conceito = "B";
    else if (media >= 6) conceito = "C";
    else if (media >= 5) conceito = "D";
    else conceito = "E";

    console.log(`Média: ${media.toFixed(2)} - Conceito: ${conceito}`);
}

// Exemplo de uso:
calcularConceito(8.5, 7.0, 9.0);