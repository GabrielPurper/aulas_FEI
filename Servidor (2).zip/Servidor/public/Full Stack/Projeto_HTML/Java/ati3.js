function areaTriangulo(base, altura) {
    if (base <= 0 || altura <= 0) {
        console.log("Erro: As medidas devem ser maiores que zero!");
        return;
    }

    const area = (base * altura) / 2;
    console.log(`A área do triângulo é: ${area}`);
}

areaTriangulo(10, 5);