const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

let numeros = [];

console.log("Digite os números (ou 'sair' para ver o resultado):");

rl.on('line', (input) => {
    if (input.toLowerCase() === 'sair') {
        gerarEstatisticas();
        rl.close();
        return;
    }

    const num = parseFloat(input);
    if (!isNaN(num)) {
        numeros.push(num);
    } else {
        console.log("Por favor, digite um número válido ou 'sair'.");
    }
});

function gerarEstatisticas() {
    if (numeros.length === 0) {
        console.log("Nenhum número foi digitado.");
        return;
    }

    const soma = numeros.reduce((a, b) => a + b, 0);
    const qtd = numeros.length;
    const media = soma / qtd;
    const maior = Math.max(...numeros);
    const menor = Math.min(...numeros);
    
    const pares = numeros.filter(n => n % 2 === 0);
    const mediaPares = pares.length > 0 ? (pares.reduce((a, b) => a + b, 0) / pares.length) : 0;
    
    const impares = numeros.filter(n => n % 2 !== 0);
    const porcentagemImpares = (impares.length / qtd) * 100;

    console.log("\n======= RESULTADOS =======");
    console.log(`a. Soma: ${soma}`);
    console.log(`b. Quantidade: ${qtd}`);
    console.log(`c. Média: ${media.toFixed(2)}`);
    console.log(`d. Maior: ${maior}`);
    console.log(`e. Menor: ${menor}`);
    console.log(`f. Média dos pares: ${mediaPares.toFixed(2)}`);
    console.log(`g. % de Ímpares: ${porcentagemImpares.toFixed(2)}%`);
    console.log("==========================\n");
}